# init.py
initapp("hello", False, False)