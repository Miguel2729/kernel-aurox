import os
import shutil
testsOS = distro("testsOS", "2.1", [], [], [], [], None, True, True, [])
while True:
    try:
    	a = input(f"{os.getcwd()}>")
    except EOFerror:
    	break
    if a == 'mount':
        a = input('nome: ')
        b = input('fs: ')
        mnt(b, a)
    elif a == 'umount':
        a = input('nome: ')
        umnt(a)
    elif a == 'cfgmnt':
        # Configurar filesystem montado
        nomefs = input('nome do filesystem montado: ')
        tipo = input('tipo (hardware/diretorio/codigo_paralelo/rede): ')
        destino = input('destino: ')
        
        # Parâmetros extras baseados no tipo
        params = {}
        if tipo == 'hardware':
            if input('configurar baud_rate? (s/n): ').lower() == 's':
                params['baud_rate'] = int(input('baud_rate: '))
        elif tipo == 'diretorio':
            if input('criar diretorio se não existir? (s/n): ').lower() == 's':
                params['criar_diretorio'] = True
            params['sync_mode'] = input('modo sync (readonly/mirror): ') or 'readonly'
        elif tipo == 'codigo_paralelo':
            params['intervalo'] = int(input('intervalo execução (segundos): ') or 5)
        elif tipo == 'rede':
            params['protocolo'] = input('protocolo (http/ftp/nfs): ') or 'http'
            params['porta'] = int(input('porta: ') or 80)
        
        configurar_fs(nomefs, tipo, destino, params)
    elif a.startswith('cd '):
        dir = a[3:]
        os.chdir(dir)
    elif a.startswith('rmdir '):
        dir = a[6:]
        shutil.rmtree(dir)
    elif a.startswith('rmfile '):
        file = a[7:]
        os.remove(file)
    elif a.startswith('mkdir '):
        dir = a[6:]
        os.mkdir("dir")
    elif a.startswith('print '):
        txt = a[6:]
        print(txt)
    elif a.startswith('view '):
        file = a[5:]
        with open(file, 'r') as file:
            print(file.read())
    elif a == 'exit':
        quit()
    elif a == 'lf':
        lista = os.listdir()
        for nomes in lista:
            if os.path.isfile(nomes):
                print(f'📄 {nomes}')
            else:
                print(f'📂 {nomes}')
    elif a == 'lp':
        listar_proc(True)
    elif a.startswith('kill '):
        pid = int(a[5:])
        matar_proc(pid, True)
    elif a == 'shutdown':
        pwroff_krnl()
    elif a == 'memprot':
        a = testsOS.return_debug()
        print(a[3])
    elif a.startswith('initapp '):
        b = a[8:]
        initapp(b, False, True)
    elif a.startswith('initapprm '):
        b = a[10:]
        initapp(b, True, True)
    elif a == "ved":
        b = input("nome ou pid?(N/p): ")
        if b == "N" or b == "n":
            c = input("nome: ")
            existe, info = VED(None, c, "name")
            if existe:
                print(f"existe!, pid: {info}")
            else:
                print("não existe")
        elif b == "P" or b == "p":
            c = int(input("pid: "))
            existe, info = VED(c, None, "pid")
            if existe:
                print(f"existe!, nome: {info}")
    elif a == "allfalse":
        for i in range(500):
            hw_instan.mem_prot[i] = False
    elif a == "alltrue":
        for i in range(500):
            hw_instan.mem_prot[i] = True