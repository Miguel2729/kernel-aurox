# teste2.py CORRIGIDO:
import time

# Aguardar inicialização completa
time.sleep(2)

codigo = """
import time
while True:
    print("proc_son")
    time.sleep(1000)
"""

# ✅ VED retorna PID, use corretamente
existe, pid_pai = VED(None, "teste2", "name")
if existe:
    print(f"🎯 Criando filho do PID {pid_pai}")
    criar_processo_filho(pid_pai, "proc_filho", codigo)
else:
    print("❌ Processo pai não encontrado")

while True:
    print("proc_princ")
    time.sleep(1000)